# -- 解决闪退问题-->搭载python3环境

第一步：下载安装包

> 这里我们使用anaconda里面的python3环境
>
> 附下载网址：https://www.anaconda.com/products/distribution#Downloads

打开网页后翻到底部，如果你们是windows 64的操作系统，请按照下面步骤进行

> 如果不是，请匹配好对应安装包，后续安装过程一样(除了 Linux)

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/7.png)

点击对应的安装包进行下载，下载到本地后解压

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/8.png)

安装

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/10.png)

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/11.png)

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/12.png)

> 注：不要装c盘

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/13.png)

> 注：这两个一定要勾选

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/14.png)

然后跳出来安装页面，安装成功后叉掉就可以了。

# -1 验证环境是否已经安装

win + r 调出windows窗口，输入`python`

如果得到以下结果，则说明安装成功

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/15.png)