# 01 更新须知

本次更新增加了部分生活接口， 目前接口数为`17`个，具体如下

> 1. 现在的温度：now_temperature
> 2. 今天的温度：temperature
> 3. 湿度：humidity
> 4. 天气：weather
> 5. 风力：wind
> 6. 空气质量：air_quality
> 7. 晨练系数：morning_exercise
> 8. 穿衣指数：dressing
> 9. 感冒系数：get_cold
> 10. 是否适合开空调：air_conditioner
> 11. 防晒指数：spf
> 12. 天气贴士：air_tips
> 13. 气象预警：alarm
> 14. 天气预警：next_hours
> 15. 生日：birthday
> 16. 纪念日：love_day
> 17. 鸡汤：joke

# 02 新增天气预警api接口

> 附网址：https://yikeapi.com/

# 03 崭新模板

新模板请看 template.txt

# 04 程序更新

将exe程序更新升级