# -1 api接口(注册，利用)

> 我这边用的是 **聚合数据** 的 api 接口
>
> 附网址：https://www.juhe.cn/

首先注册

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/1.png)

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/2.png)

然后登陆

> 由于请求api需要身份验证，所以按照需求进行身份验证
>
> 注：验证速度比较快，我的是五分钟以内验证成功

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/3.png)

> 记住这两个 key ，很关键

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/5.png)

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/4.png)

# -2 代码配置

![](https://gitee.com/qishen-1/wxgzh/raw/master/api/img/6.png)