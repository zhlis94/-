# 01 自动化定时发送

> 注：这是电脑端定时，要保证电脑不能关机。
>
> 并且我的是windows系统，此教程以windows系统为例。



![](https://gitee.com/qishen-1/wxgzh/raw/master/Automatically_send/img/1.png)

![](https://gitee.com/qishen-1/wxgzh/raw/master/Automatically_send/img/2.png)

在选择每天定时发送前，我们不妨可以先勾选一次，看是否能按时发送

> 温馨提示：可以设置一个比较近的时间进行测试哦，比如五分钟后

![](https://gitee.com/qishen-1/wxgzh/raw/master/Automatically_send/img/3.png)

这里非常重要，如果只写了第三步的程序路径，那么将会弹出终端窗口上面显示`与config.txt不在同一路径`，所以为了解决这一问题，我们就可以在第4步的位置加入此exe之前的路径，就是粉色红框框里面的内容。

![](https://gitee.com/qishen-1/wxgzh/raw/master/Automatically_send/img/4.png)

![](https://gitee.com/qishen-1/wxgzh/raw/master/Automatically_send/img/5.png)

一切完成之后，等着时间到就好啦。

> 不出意外，你将会在五分钟后收到信息。